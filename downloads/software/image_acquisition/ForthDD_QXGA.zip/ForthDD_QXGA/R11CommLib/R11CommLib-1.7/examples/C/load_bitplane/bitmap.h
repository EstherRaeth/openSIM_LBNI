/* Forth Dimension Displays Limited, the copyright holder of this work, 
 * hereby release it into the public domain. This applies worldwide.
 * In case this is not legally possible:
 * Forth Dimension Displays Limited grant anyone the right to use this
 * work for any purpose, without any conditions, unless such conditions
 * are required by law.
 * This release applies only to this source code file.
 * Other source code files supplied along with it may be governed by
 * different terms
 */
 
#ifndef _BITMAP_H
#define _BITMAP_H

#define WINDOWS_BM_SIGNATURE        0x4D42

#define ERR_BMP_OPEN_FAILED         0x01
#define ERR_BMP_UNEXPECTED_EOF      0x02
#define ERR_BMP_INVALID_FILE        0x03
#define ERR_BMP_INVALID_SIZE        0x04
#define ERR_BMP_INVALID_BIT_DEPTH   0x05
#define ERR_BMP_MALLOC_FAILED       0x06

#define QXGA_WIDTH      2048
#define QXGA_HEIGHT     1536

#pragma pack(push, 1)

typedef struct
{
    uint16_t bfType;
    uint32_t bfSize;
    uint16_t bfReserved1;
    uint16_t bfReserved2;
    uint32_t bfOffBits;
} BITMAPFILEHEADER;

typedef struct
{
    uint32_t biSize;
    uint32_t biWidth;
    uint32_t biHeight;
    uint16_t biPlanes;
    uint16_t biBitCount;
    uint32_t biCompression;
    uint32_t biSizeImage;
    uint32_t biXPelsPerMeter;
    uint32_t biYPelsPerMeter;
    uint32_t biClrUsed;
    uint32_t biClrImportant;
} BITMAPINFOHEADER;

#pragma pack(pop)

uint8_t getBitplaneData(const char *fileName, uint8_t **bpData);

#endif
