#ifndef _CORE_API_LIBRARY_H
#define _CORE_API_LIBRARY_H

#ifdef __cplusplus
extern "C" {  
#endif

FDD_RESULT FDD_LibGetVersion(char *, uint8_t);

#ifdef __cplusplus
}
#endif

#endif // _CORE_API_LIBRARY_H
