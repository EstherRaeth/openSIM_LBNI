/* Writes a monochrome bitmap image to the first bitplane locations in
 * the external Flash of a QXGA-3DM.
 *
 * Forth Dimension Displays Limited, the copyright holder of this work, 
 * hereby release it into the public domain. This applies worldwide.
 * In case this is not legally possible:
 * Forth Dimension Displays Limited grant anyone the right to use this
 * work for any purpose, without any conditions, unless such conditions
 * are required by law.
 * This release applies only to this source code file.
 * Other source code files supplied along with it may be governed by
 * different terms
 *
 *
 * This example program is intended for use with R11CommLib V1.4 or newer.
 *
 * Use MetroCon to send the repertoire "load_bitplane_test.repz11" to your
 * board and confirm that the display shows an image of the digit 1 before
 * running this program.
 * The repertoire file is located in the "Resource" subdirectory.
 *
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bitmap.h"
#include "core/api/types.h"
#include "core/api/device.h"
#include "core/api/exception.h"
#include "r11/api/library.h"
#include "r11/api/device.h"
#include "r11/api/rpc.h"
#include "r11/api/flash.h"

#define DEV_TIMEOUT    1000

//----------------------------------------------------------------

static void checkError(FDD_RESULT res)
{
    if(res != FDD_SUCCESS)
    {
        FDD_DevClose();
        printf("Error %d", res);
    
        if(res == FDD_SLAVE_EXCEPTION)
        {
            const char *exc;

            FDD_ExcGetMsg(&exc);
            printf(": \"%s\"", exc);
        }
    
        printf("\n\n");
        exit(-1);
    }
}

//----------------------------------------------------------------

static uint8_t revBits(uint8_t v)
{
    return  ((v & 0x80) >> 7) | ((v & 0x40) >> 5) |
            ((v & 0x20) >> 3) | ((v & 0x10) >> 1) |
            ((v & 0x08) << 1) | ((v & 0x04) << 3) |
            ((v & 0x02) << 5) | ((v & 0x01) << 7);
}

//----------------------------------------------------------------

static FDD_RESULT sendBitplane(const uint8_t *bpData)
{
    FDD_RESULT res;
    uint8_t pageData[EF_PAGE_SIZE];
    const uint8_t *rowData;
    uint16_t pageNum = 0;
    uint16_t byteNum = 0;
    uint16_t row, col;
    uint16_t byteWidth = QXGA_WIDTH / 8;
    int32_t lastBlockNum = -1;
    uint16_t blockNum;
    
    for(row = 0; row < QXGA_HEIGHT; row++)        
    {
        rowData = bpData + (row * byteWidth); // Ptr to start of row in bpData

        for(col = 0; col < byteWidth / 4; col++)
        {
            pageData[byteNum++] = revBits(rowData[0x00]);
            pageData[byteNum++] = revBits(rowData[0x40]);
            pageData[byteNum++] = revBits(rowData[0x80]);
            pageData[byteNum++] = revBits(rowData[0xC0]);
            rowData++;

            if(byteNum == EF_PAGE_SIZE)
            {
                blockNum = pageNum / EF_PAGES_PER_BLOCK;

                // If this is the first page in a new block, then erase the block.
                if(blockNum != lastBlockNum)
                {
                    // Block to be erased is specified using any page within the block.
                    R11_RpcFlashEraseBlock(EF_IMAGE_BASE + pageNum);
                    lastBlockNum = blockNum;
                }

                // Write page data to Flash buffer.
                res = R11_FlashWrite(pageData, 0, EF_PAGE_SIZE);
                if(res != FDD_SUCCESS) return res;

                // Write page data from Flash buffer to Flash device.
                res = R11_FlashBurn(EF_IMAGE_BASE + pageNum);
                if(res != FDD_SUCCESS) return res;

                pageNum++;
                byteNum = 0;
            }
        }
    }

    return FDD_SUCCESS;
}

//----------------------------------------------------------------

static void showDevices(char *argv[])
{
    char *devId, *devSn;

    printf("Usage:\n");
    printf("\t%s <USB Serial Number> <Bitmap File>\n\n", argv[0]);
    printf("USB Serial Numbers:\n");

    FDD_DevEnumerateWinUSB(R11_WINUSB_GUID, NULL, NULL);
    FDD_DevGetFirst(&devId);

    while(devId)
    {
        devSn = strchr(devId, ':');

        if(devSn != NULL)
        {
            *devSn++ = '\0';
            printf("\t%s\n", devSn);
        }

        FDD_DevGetNext(&devId);
    }
}

//----------------------------------------------------------------

static FDD_RESULT openDevice(char *argv[])
{
    char *devId, *devSn;

    FDD_DevEnumerateWinUSB(R11_WINUSB_GUID, NULL, NULL);
    FDD_DevGetFirst(&devId);

    while(devId)
    {
        devSn = strchr(devId, ':');

        if(devSn != NULL)
        {
            *devSn++ = '\0';

           // if(_stricmp(devSn, argv[1]) == 0) // USB serial number
           // {
                return FDD_DevOpenWinUSB(devId, DEV_TIMEOUT);
				break;
            //}
        }

        FDD_DevGetNext(&devId);
    }

    printf("Device '%s' not found\n", argv[1]);

    return FDD_DEV_NOT_FOUND;
}

//----------------------------------------------------------------

int main(int argc, char *argv[])
{
    FDD_RESULT res;
    uint8_t status;
    uint8_t *bpData, pro;
    char verStr[64] = "\0";
    
    res = R11_LibGetVersion(verStr, sizeof(verStr));
    checkError(res);
    printf("R11CommLib V%s\n\n", verStr);
    if(argc != 3)
    {
        showDevices(argv);
		printf("Test2");
    }
    else
    {
        res = openDevice(argv);
		system("Pause");
        checkError(res);
		printf("Test1");
		system("Pause");
        if((status = getBitplaneData(argv[2], &bpData)) != 0)
        {
            printf("Unable to read image \"%s\": Error %d\n", argv[2], status);
			system("Pause");
            exit(-1);
        }
		system("Pause");
        printf("Deactivate Running Order: ");
        res = R11_RpcRoDeactivate();
        checkError(res);
        printf("Ok\n");

        printf("Send Bitplane data: ");
        res = sendBitplane(bpData);
        checkError(res);
        printf("Ok\n");

		system("Pause");

        printf("Reload Repertoire: ");
        res = R11_RpcSysReloadRepertoire();
        free(bpData);
        checkError(res);

        do
        {
            res = R11_DevGetProgress(&pro);
            checkError(res);
            printf("\rReload Repertoire: %d%%", pro);
        } while(pro != 100);
        
        /*printf("\nClose device: ");
        res = FDD_DevClose();
        checkError(res);
        printf("Ok\n");*/
    }
	system("Pause");
	R11_RpcRoActivate();
	system("Pause");
    return 0;
}

//
//int main(int argc, char *argv[])
//{
//	FDD_RESULT res;
//	uint8_t status;
//	uint8_t *bpData, pro;
//	char verStr[64] = "\0";
//	res = openDevice(argv);
//
//	printf("Deactivate Running Order: ");
//	res = R11_RpcRoDeactivate();
//	checkError(res);
//	printf("Ok\n");
//
//	printf("Reload Repertoire: ");
//	res = R11_RpcSysReloadRepertoire();
//	free(bpData);
//	checkError(res);
//
//	res = R11_LibGetVersion(verStr, sizeof(verStr));
//	checkError(res);
//	printf("R11CommLib V%s\n\n", verStr);
//
//	if (argc != 3)
//	{
//		showDevices(argv);
//		printf("Test2");
//	}
//	else
//	{
//		res = openDevice(argv);
//		checkError(res);
//		printf("Test1");
//		if ((status = getBitplaneData(argv[2], &bpData)) != 0)
//		{
//			printf("Unable to read image \"%s\": Error %d\n", argv[2], status);
//			exit(-1);
//		}
//
//		printf("Deactivate Running Order: ");
//		res = R11_RpcRoDeactivate();
//		checkError(res);
//		printf("Ok\n");
//
//		printf("Send Bitplane data: ");
//		res = sendBitplane(bpData);
//		checkError(res);
//		printf("Ok\n");
//
//		printf("Reload Repertoire: ");
//		res = R11_RpcSysReloadRepertoire();
//		free(bpData);
//		checkError(res);
//
//		do
//		{
//			res = R11_DevGetProgress(&pro);
//			checkError(res);
//			printf("\rReload Repertoire: %d%%", pro);
//		} while (pro != 100);
//
//		printf("\nClose device: ");
//		res = FDD_DevClose();
//		checkError(res);
//		printf("Ok\n");
//	}
//	system("Pause");
//	return 0;
//}



