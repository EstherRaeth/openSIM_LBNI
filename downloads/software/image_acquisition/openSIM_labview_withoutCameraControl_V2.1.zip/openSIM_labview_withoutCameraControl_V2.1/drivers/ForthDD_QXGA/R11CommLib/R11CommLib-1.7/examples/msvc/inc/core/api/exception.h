#ifndef _CORE_API_EXCEPTION_H
#define _CORE_API_EXCEPTION_H

#ifdef __cplusplus
extern "C" {  
#endif

FDD_RESULT FDD_ExcGetMsg(const char **);

#ifdef __cplusplus
}
#endif

#endif // _CORE_API_EXCEPTION_H
