/* Connect to an R11 over RS-485 and retrieve various board information.
 *
 * Forth Dimension Displays Limited, the copyright holder of this work, 
 * hereby release it into the public domain. This applies worldwide.
 * In case this is not legally possible:
 * Forth Dimension Displays Limited grant anyone the right to use this
 * work for any purpose, without any conditions, unless such conditions
 * are required by law.
 * This release applies only to this source code file.
 * Other source code files supplied along with it may be governed by
 * different terms
 *
 */
//#include "extcode.h"
#include <windows.h>


#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#include "core/api/types.h"
#include "core/api/exception.h"
#include "core/api/library.h"
#include "core/api/device.h"

#include "r11/api/library.h"
#include "r11/api/rpc.h"
#include "r11/api/device.h"

#define DEV_TIMEOUT    1000



_declspec(dllexport) void WinCHAR(CHAR *input, PCHAR output)
{
	size_t i, j;

	/* Reverse "i" characters. Assume output already has memory. */
	for (i = strlen(input), j = 0; i > 0; j++)
	{
		output[j] = input[--i];
	}
}


static FDD_RESULT checkRes(FDD_RESULT res)
{
    if(res != FDD_SUCCESS)
    {
        if(res == FDD_SLAVE_EXCEPTION)
        {
            const char *excMsg;

            FDD_ExcGetMsg(&excMsg);
            printf("Error: 0x%02X: \"%s\"\n", res, excMsg);
        }
        else
        {
            printf("Error: 0x%02X\n", res);
        }
    }

    return res;
}

//----------------------------------------------------------------

static FDD_RESULT getLibVersions(void)
{
    FDD_RESULT res;
    char ver[64] = "\0";

    res = FDD_LibGetVersion(ver, sizeof(ver));
    if(res != FDD_SUCCESS) return res;
    printf("CommLib V%s\n", ver);

    res = R11_LibGetVersion(ver, sizeof(ver));
    if(res != FDD_SUCCESS) return res;
    printf("R11CommLib V%s\n\n", ver);

    return FDD_SUCCESS;
}

//----------------------------------------------------------------

static void showDevices(char *argv[])
{
    char *devId, *devSn;

    printf("Usage:\n");
    printf("\t%s <COM Port>\n", argv[0]);
    printf("\t%s <USB Serial Number>\n", argv[0]);
    printf("\t%s <COM Port> <RS485 Addr>\n\n", argv[0]);
    
    printf("COM Ports:\n");
    FDD_DevEnumerateComPorts(NULL, NULL);
    FDD_DevGetFirst(&devId);

    while(devId)
    {
        printf("\t%s\n", devId);
        FDD_DevGetNext(&devId);
    }

    printf("\nUSB Serial Numbers:\n");
    FDD_DevEnumerateWinUSB(R11_WINUSB_GUID, NULL, NULL);
    FDD_DevGetFirst(&devId);

    while(devId)
    {
        devSn = strchr(devId, ':');

        if(devSn != NULL)
        {
            *devSn++ = '\0';
            printf("\t%s\n", devSn);
        }

        FDD_DevGetNext(&devId);
    }
}

//----------------------------------------------------------------

static FDD_RESULT openDevice(int argc, char *argv[])
{
    FDD_RESULT res;
    char *devId, *devSn;

    FDD_DevEnumerateComPorts(NULL, NULL);
    FDD_DevGetFirst(&devId);

    while(devId)
    {
        if(argc > 2) // COM port with RS-485 address?
        {
            if(_stricmp(devId, argv[1]) == 0)
            {
                res = FDD_DevOpenComPort(devId, DEV_TIMEOUT, R11_RS485_BAUDRATE, FALSE);
                if(res != FDD_SUCCESS) return res;
                return R11_RpcSysSelectAddr(atoi(argv[2]));
            }
        }
        else if(argc > 1) // COM port?
        {
            if(_stricmp(devId, argv[1]) == 0)
            {
                return FDD_DevOpenComPort(devId, DEV_TIMEOUT, R11_RS232_BAUDRATE, TRUE);
            }
        }

        FDD_DevGetNext(&devId);
    }

    FDD_DevEnumerateWinUSB(R11_WINUSB_GUID, NULL, NULL);
    FDD_DevGetFirst(&devId);

    while(devId)
    {
        devSn = strchr(devId, ':');

        if(devSn != NULL)
        {
            *devSn++ = '\0';

            if(_stricmp(devSn, argv[1]) == 0) // USB serial number
            {
                return FDD_DevOpenWinUSB(devId, DEV_TIMEOUT);
            }
        }

        FDD_DevGetNext(&devId);
    }

    printf("Device '%s' not found\n", argv[1]);

    return FDD_DEV_NOT_FOUND;
}

//----------------------------------------------------------------

static FDD_RESULT getMicroCodeInfo(void)
{
    FDD_RESULT res;
    uint16_t ver[4];
    char timestamp[32] = "\0";

    res = R11_RpcMicroGetCodeVersion(ver);
    if(res != FDD_SUCCESS) return res;
    
    printf("Micro Code V%d.%d.%d.%d ", ver[3], ver[2], ver[1], ver[0]);
    
    res = R11_RpcMicroGetCodeTimestamp(timestamp, sizeof(timestamp));
    if(res != FDD_SUCCESS) return res;

    printf("(%s)\n\n", timestamp);

    return res;
}

//----------------------------------------------------------------

static FDD_RESULT getBoardSupplies(void)
{
    FDD_RESULT res;
    uint16_t value;
    float voltage;
    uint8_t i;

    typedef struct
    {
        uint8_t channel;
        const char *supply; 
        float factor;
    } Adc;

    const Adc adc[] = {3, "1V1", 1.0f,
                       2, "1V2", 1.0f,
                       0, "1V8", 1.0f,
                       7, "2V5", 1.0f,
                       6, "3V3", 0.5f,
                       5, "5V",  0.5f,
                       4, "12V", 10.0f/66};
    
    printf("Board Supplies: ");
    for(i = 0; i < sizeof(adc) / sizeof(Adc); i++)
    {
        printf("%s\t", adc[i].supply);
    }
    printf("\n                ");

    for(i = 0; i < sizeof(adc) / sizeof(Adc); i++)
    {
        res = R11_RpcSysGetADC(adc[i].channel, &value);
        if(res != FDD_SUCCESS) return res;

        voltage = (3.0f * value) / (1023.0f * adc[i].factor);
        printf("%.2f\t", voltage);
    }
    printf("\n");

    return FDD_SUCCESS;
}

//----------------------------------------------------------------

static FDD_RESULT getDisplayTemp(void)
{
    FDD_RESULT res;
    uint16_t disp_temp;
    float temp_degrees;

    res = R11_RpcSysGetDisplayTemp(&disp_temp);
    if(res != FDD_SUCCESS) return res;

    disp_temp >>= 4;

    if(disp_temp < 2048)
    {
        temp_degrees = (float)disp_temp / 16;
    }
    else
    {
        temp_degrees = -((float)(4096 - disp_temp)) / 16;
    }

    printf("Display Temp:\t%.1fC\n", temp_degrees);

    return res;
}

//----------------------------------------------------------------

static FDD_RESULT getDisplayInfo(void)
{
    FDD_RESULT res;
    uint8_t disp_type;

    res = R11_RpcSysGetDisplayType(&disp_type);
    if(res != FDD_SUCCESS) return res;

    printf("Display Type:\t");

    switch(disp_type)
    {
        case DISPLAY_TYPE_NONE:
            printf("None\n");
            break;

        case DISPLAY_TYPE_M150:
            printf("M150\n");
            return getDisplayTemp();
            break;

        default:
            printf("Unknown (0x%02X)\n", disp_type);
    }

    return res;
}

//----------------------------------------------------------------

static FDD_RESULT getSystemInfo(void)
{
    FDD_RESULT res;
    uint8_t board_type, board_id;
    uint32_t serial_num;

    res = R11_RpcSysGetSerialNum(&serial_num);
    if(res != FDD_SUCCESS) return res;
    printf("Serial Number:\t%d\n", serial_num);
    
    res = R11_RpcSysGetBoardType(&board_type);
    if(res != FDD_SUCCESS) return res;
    printf("Board Type:\t%s\n", (board_type == MAINBOARD_TYPE_M175) ? "M175" : "Unknown");

    res = R11_RpcSysGetBoardID(&board_id);
    if(res != FDD_SUCCESS) return res;
    printf("Board Rev:\t%s\n", (board_id == MAINBOARD_REV_A) ? "A" : "Unknown");

    return res;
}

//----------------------------------------------------------------


	_declspec(dllexport) int OpendevicePersonal()
	{
		
		FDD_RESULT res;
		res = FDD_SLAVE_ERROR;
		char *devId, *devSn;

		getLibVersions();

		FDD_DevEnumerateWinUSB(R11_WINUSB_GUID, NULL, NULL);
		FDD_DevGetFirst(&devId);

		while (devId)
		{
			devSn = strchr(devId, ':');

			if (devSn != NULL)
			{
				*devSn++ = '\0';
				res = FDD_DevOpenWinUSB(devId, DEV_TIMEOUT);
				checkRes(res);
				break;
			}

			FDD_DevGetNext(&devId);

		}
		if (checkRes(res) != FDD_SUCCESS)
		{
			return res;
		}

		if (checkRes(res) != FDD_SUCCESS) return res;

		res = getMicroCodeInfo();
		if (checkRes(res) != FDD_SUCCESS) return res;

		res = getSystemInfo();
		if (checkRes(res) != FDD_SUCCESS) return res;

		res = getDisplayInfo();
		if (checkRes(res) != FDD_SUCCESS) return res;

		res = getBoardSupplies();
		if (checkRes(res) != FDD_SUCCESS) return res;

		return 0;
	}

	_declspec(dllexport) int ResetDevice()
	{
		FDD_RESULT res;
		res = FDD_SLAVE_ERROR;

		getLibVersions();

		res = R11_RpcRoDeactivate();
		if (checkRes(res) != FDD_SUCCESS)
		{
			return res;
		}
		res = R11_RpcRoActivate();\
		if (checkRes(res) != FDD_SUCCESS)
		{
			return res;
		}

		return 0;
	}

	//_declspec(dllexport) int SetFlipPatern(uint8_t bitstosend)
	//{
	//	FDD_RESULT res;

	//	res = R11_RpcFlipTpSet(bitstosend);

	//	return res;
	//
	//}

	_declspec(dllexport) void getROname7(uint16_t RO,  PCHAR output)
	{
		FDD_RESULT resss;
		int i;
		uint8_t lenght = 0xff;
		char   name[254];
		resss = R11_RpcRoGetName(RO,&name, lenght);
		for (i = 0; i < strlen(name); i++)
		{
			output[i] = name[i];
		}
	}




	int main()
	{
		//FDD_RESULT ress;
		//uint8_t getbit= 00000000;
		//OpendevicePersonal();
		////ResetDevice();
		//system("PAUSE");
		////ress = R11_RpcRoDeactivate();
		////ress = R11_RpcRoActivate();
		//ress = R11_RpcFlipTpSet(11010100);

		//system("PAUSE");
		////ress = R11_RpcRoActivate();
		//ress = R11_RpcFlipTpGet(&getbit);
		///*if (checkRes(ress) != FDD_SUCCESS)
		//{
		//	return ress;
		//}*/
		//printf("%" PRIu8, getbit);
		//system("PAUSE");
		//FDD_RESULT ress;
		//OpendevicePersonal();
		//uint16_t roset;
		//roset = 0x000000001;
		//printf("PAUSE1");
		//system("PAUSE");
		//ress = R11_RpcRoGetSelected(&roset);
		//printf("PAUSE2");
		//system("PAUSE");
		//uint16_t RO = 0x000000001;
		//char  name[254];
		///*name = ( 'h', 'i' );*/
		//uint8_t lenght = 0xfe;
		//printf("PAUSE3");
		//system("PAUSE");
		//ress = R11_RpcRoGetName(roset, &name, lenght);
		////printf("integer=%d, string=%.*s, number=%f", integer, lenght, name, number);
		//printf("PAUSE4");
		//system("PAUSE");
		//char frite = name;
		////printf("%.1s", lenght, frite);
		//printf("Oui");
		//system("PAUSE");
		//ress = FDD_DevClose();
		FDD_RESULT ress;
		OpendevicePersonal();
		char * namee = malloc(254 * sizeof(char));
		uint16_t RO = 0x000000004;
		char* autre = 'i';
		char nameee[254]; 
		CHAR *input1[254];
		PCHAR output1[254];
		//ress = getROname4(RO, output1);
		ress = FDD_DevClose();
		free(namee);
		return 0;
		
	}
