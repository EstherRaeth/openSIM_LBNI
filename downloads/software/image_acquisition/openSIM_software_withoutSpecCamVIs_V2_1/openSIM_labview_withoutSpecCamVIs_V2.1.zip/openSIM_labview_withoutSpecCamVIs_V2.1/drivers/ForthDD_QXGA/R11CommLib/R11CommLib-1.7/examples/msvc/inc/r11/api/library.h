#ifndef _R11_API_LIB_H
#define _R11_API_LIB_H

#ifdef __cplusplus
extern "C" {  
#endif

FDD_RESULT R11_LibGetVersion(char *, uint8_t);

#ifdef __cplusplus
}
#endif

#endif // _R11_API_LIB_H