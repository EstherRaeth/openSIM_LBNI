/* error.c - Currently only defined to use error.h
 *
 * Created by Ryan Orendorff <ro265@cam.ac.uk>
 * Date: 08/01/12 19:20:14
 *
 * Copyright GPL V3
 */

#include "error.h"
