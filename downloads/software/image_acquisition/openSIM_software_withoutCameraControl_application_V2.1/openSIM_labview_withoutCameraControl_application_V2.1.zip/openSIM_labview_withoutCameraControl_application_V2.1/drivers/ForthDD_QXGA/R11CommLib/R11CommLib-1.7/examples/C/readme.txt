
The following command-line programs are provided as examples of how to use R11CommLib to control a QXGA-3DM board.
These example projects were created with Visual Studio Express 2013 for Windows Desktop.
You may encounter compatibility issues if you attempt to open these projects with a different version of Visual Studio.

board_info
---------

On execution, board_info connects to a QXGA-3DM over RS-485 and returns a number of boarding settings.
The program requires the COM port and RS-485 address as command-line parameters.

To build the board_info example, open the project solution file named "board_info.sln"
In Visual Studio, choose the appropriate target platform for the build ("x64" or "Win32"), and then select "Build Solution" from the Build menu.

load_bitplane
-------------

load_bitplane accepts a device ID and bitmap file name as command-line parameters. Run it without any parameters to receive a list of candidate device IDs. Any leading zeroes must be included when specifying the device ID.

On execution, load_bitplane will connect to the specified board, deactivate the current Running Order, send the bitmap image data to the external Flash of the QXGA-3DM board, and then initiate reloading of the repertoire before finally disconnecting.

To build the load_bitplane example, navigate to the "build" directory within "load_bitplane" and open the project solution file named "load_bitplane.sln"
In Visual Studio, choose the appropriate target platform for the build ("x64" or "Win32"), and then select "Build Solution" from the Build menu.

Before running load_bitplane for the first time, use MetroCon to send the example repertoire to the 3DM board. The example repertoire is located in the "load_bitplane\resources" directory. If the repertoire was sent correctly, a large digit '1' should be clearly visible on the microdisplay.
Disconnect from the board in MetroCon and use load_bitplane to send the bitmap image '2.bmp' (also located in "load_bitplane\resources") to the board.
