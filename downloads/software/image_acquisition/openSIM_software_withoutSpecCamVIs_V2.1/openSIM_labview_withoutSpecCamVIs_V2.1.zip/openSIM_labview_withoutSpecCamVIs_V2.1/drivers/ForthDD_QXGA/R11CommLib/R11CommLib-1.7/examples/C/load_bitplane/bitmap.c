/* Forth Dimension Displays Limited, the copyright holder of this work, 
 * hereby release it into the public domain. This applies worldwide.
 * In case this is not legally possible:
 * Forth Dimension Displays Limited grant anyone the right to use this
 * work for any purpose, without any conditions, unless such conditions
 * are required by law.
 * This release applies only to this source code file.
 * Other source code files supplied along with it may be governed by
 * different terms
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "bitmap.h"

uint8_t getBitplaneData(const char *fileName, uint8_t **bpData)
{
    BITMAPFILEHEADER bmFileHeader;
    BITMAPINFOHEADER bmInfoHeader;
    uint32_t byteWidth = QXGA_WIDTH / 8;
    uint32_t byteCount = QXGA_HEIGHT * byteWidth;    
    uint16_t row;
    size_t bytesRead;
    uint8_t *bmData;
    FILE *fp;

    fp = fopen((char *)fileName, "rb");
	if(fp == NULL) return ERR_BMP_OPEN_FAILED;

    // Get bitmap file header
    bytesRead = fread(&bmFileHeader, 1, sizeof(BITMAPFILEHEADER), fp);
    if(bytesRead != sizeof(BITMAPFILEHEADER)) return ERR_BMP_UNEXPECTED_EOF;
    if(bmFileHeader.bfType != WINDOWS_BM_SIGNATURE) return ERR_BMP_INVALID_FILE;

    // Get bitmap info header
    bytesRead = fread(&bmInfoHeader, 1, sizeof(BITMAPINFOHEADER), fp);
    if(bytesRead != sizeof(BITMAPINFOHEADER)) return ERR_BMP_UNEXPECTED_EOF;

    // Check image dimensions and bit-depth
    if((bmInfoHeader.biWidth != QXGA_WIDTH) || (bmInfoHeader.biHeight != QXGA_HEIGHT)) return ERR_BMP_INVALID_SIZE;
    if(bmInfoHeader.biBitCount != 1) return ERR_BMP_INVALID_BIT_DEPTH;

    // Skip over palette data    
    fseek(fp, 8, SEEK_CUR);
    
    // Allocate bitmap image buffer
    bmData = (uint8_t *)malloc(byteCount);
    if(bmData == NULL) return ERR_BMP_MALLOC_FAILED;

    // Get bitmap image data
    bytesRead = fread(bmData, 1, byteCount, fp);
    if(bytesRead < byteCount) return ERR_BMP_UNEXPECTED_EOF;

    fclose(fp);

    // Allocate bitplane buffer
    *bpData = (uint8_t *)malloc(byteCount);
    if(*bpData == NULL) return ERR_BMP_MALLOC_FAILED;

    // Copy bitmap image buffer (bmData) to QXGA-3DM bitplane buffer (bpData).
    // - bmData is stored left-to-right/bottom-to-top.
    // - bpData is stored left-to-right/top-to-bottom.

    for(row = 0; row < QXGA_HEIGHT; row++)
    {
        memcpy(*bpData + (row * byteWidth), bmData + ((QXGA_HEIGHT - 1 - row) * byteWidth), byteWidth);
    }

    free(bmData);

    return 0;
}
